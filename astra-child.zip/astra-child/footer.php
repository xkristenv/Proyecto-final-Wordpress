<?php
?>
    </div>

    <footer class="site-footer-custom">

        <div class="container footer-content">

            <div class="footer-brand">
                <h3 class="footer-logo">Pure Bloom Skincare</h3>

                <p class="footer-description">
                    Descubre productos diseñados para hidratar, proteger y resaltar la belleza natural de tu piel.
                </p>
            </div>

            <div class="footer-links">
                <strong>Explorar</strong>

                <a href="<?php echo home_url(); ?>">Inicio</a>

                <a href="<?php echo home_url('/about-us'); ?>">
                    Sobre Nosotros
                </a>

                <a href="<?php echo home_url('/blog'); ?>">
                    Blog
                </a>

                <a href="<?php echo home_url('/product'); ?>">
                    Productos
                </a>
            </div>

            <div class="footer-social">
                <strong>Síguenos</strong>

                <div class="social-icons">
                    <a href="#" class="social-link">Facebook</a>
                    <a href="#" class="social-link">Instagram</a>
                    <a href="#" class="social-link">TikTok</a>
                </div>
            </div>

        </div>

        <div class="footer-bottom">
            <p>
                © <?php echo date('Y'); ?>
                Pure Bloom Skincare | Proyecto Final WordPress
            </p>
        </div>

    </footer>

    <?php wp_footer(); ?>
</body>
</html>