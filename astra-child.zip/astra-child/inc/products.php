<?php

function register_products_cpt() {

    register_post_type('product', array(
        'labels' => array(
            'name' => 'Products',
            'singular_name' => 'Product'
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-products',
        'supports' => array(
            'title',
            'editor',
            'thumbnail'
        ),
        'show_in_rest' => true
    ));

}

add_action('init', 'register_products_cpt');