<?php get_header(); ?>

<div class="products-page">

    <h1 class="products-title">Nuestros Productos</h1>

    <p class="products-subtitle">
        Descubre nuestra colección de productos para el cuidado de la piel.
    </p>

    <div class="products-grid">

        <?php if (have_posts()) : ?>

            <?php while (have_posts()) : the_post(); ?>

                <div class="product-card">

                    <?php if (has_post_thumbnail()) : ?>
                        <div class="product-image">
                            <?php the_post_thumbnail('medium'); ?>
                        </div>
                    <?php endif; ?>

                    <h2><?php the_title(); ?></h2>

                    <div class="product-description">
                        <?php the_excerpt(); ?>
                    </div>

                    <a href="<?php the_permalink(); ?>" class="product-btn">
                        Ver Producto
                    </a>

                </div>

            <?php endwhile; ?>

        <?php endif; ?>

    </div>

    <div class="back-home-container">
        <a href="<?php echo get_permalink(get_page_by_path('home')); ?>" class="back-home-btn">
            ← Volver al Inicio
        </a>
    </div>

</div>

<?php get_footer(); ?>