<?php get_header(); ?>

<div class="product-page">

<?php while(have_posts()) : the_post(); ?>

    <h1><?php the_title(); ?></h1>

    <?php if(has_post_thumbnail()) : ?>
        <?php the_post_thumbnail('large'); ?>
    <?php endif; ?>

    <div class="product-content">
        <?php the_content(); ?>
    </div>

<?php endwhile; ?>

</div>

<div class="back-home-container">
    <a href="<?php echo get_permalink( get_page_by_path('home') ); ?>" class="back-home-btn">
        ← Volver al inicio
    </a>
</div>

<?php get_footer(); ?>