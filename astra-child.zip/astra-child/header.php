<?php
/**
 * The header for Astra Theme.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content">
    <?php echo esc_html( astra_default_strings( 'string-header-skip-link', false ) ); ?>
</a>

<div id="page" class="hfeed site"> <header class="site-header-custom">
        <div class="container">
            
            <div class='site-logo'>
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                        <h1 class='site-title'><?php bloginfo('name'); ?></h1>
                    </a>
                <?php endif; ?>
            </div>

            <button class="menu-toggle-btn" aria-label="Abrir menú">
                <span class="hamburger"></span>
            </button>

            <nav id="site-navigation" class="main-navigation">
                <?php 
                    wp_nav_menu(
                        [
                            'theme_location'=>'header-menu-hijo',
                            'menu_id'=>'primary_menu',
                            'container'=>false,
                            'depth' => 3
                        ]
                    );
                ?>
            </nav>
        </div>
    </header>

    <div id="content" class="site-content">
        <div class="ast-container">